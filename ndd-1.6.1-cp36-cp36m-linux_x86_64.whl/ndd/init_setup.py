import os

SEP = os.path.sep
PATHSEP = os.pathsep


def add_libs_dir():
    libs_dir = os.path.join(project_path, '.libs')
    if os.path.isdir(libs_dir):
        print('is dir')
        os.environ['PATH'] += PATHSEP + libs_dir
    else:
        print('is not dir')
        libs_dir = None
    return libs_dir


def subclasses(cls):
    """Return a dict name -> class for all subclasses of class `cls`."""
    return {sc.__name__: sc for sc in cls.__subclasses__()}


project_path = os.path.dirname(os.path.abspath(__file__))
project_name = project_path.split(SEP)[-1]

libs_dir = add_libs_dir()
if libs_dir:
    print('%r added to PATH' % libs_dir)
