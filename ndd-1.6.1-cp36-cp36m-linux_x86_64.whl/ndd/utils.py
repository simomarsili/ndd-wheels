import os


def add_libs_dir():
    project_path = os.path.dirname(os.path.abspath(__file__))
    libs_dir = os.path.join(project_path, '.libs')
    print(libs_dir)
    if os.path.isdir(libs_dir):
        os.environ['PATH'] += os.pathsep + libs_dir
    else:
        libs_dir = None
    return libs_dir


libs_dir = add_libs_dir()
if libs_dir:
    print('%r added to PATH')
